package com.example.androidversions10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.androidversions10.databinding.CardviewBinding;

public class AndroidVersion {
     int imageResId;
     String codeName;
     String version;

    public AndroidVersion(int imageResId , String codeName , String version){
        this.imageResId= imageResId;
        this.codeName=codeName;
        this.version=version;

    }



}
